
        <?php
            
            $site=$_GET["s"];
            // $dis="COL";
            require_once "../db_php_files/connection.php";

            $sql="SELECT date,SUM(4g_device_count),SUM(3g_device_count),SUM(2g_device_count) FROM site_summary WHERE LEFT(site_id,2)=? GROUP BY YEAR(date)+'-'+MONTH(date)";
            
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"s",$param_site);

                $param_site=$site;

                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    
                    $data_m=$data_4g=$data_3g=$data_2g=array();
                    $a=$b=$c=$d=0;
                    

                    if(mysqli_stmt_num_rows($stmt)>=1){
                        mysqli_stmt_bind_result($stmt,$date,$fourG,$threeG,$twoG);
                        
                        while(mysqli_stmt_fetch($stmt)){
                            $data_m[$a++]=$date;
                            $data_4g[$b++]=$fourG;
                            $data_3g[$c++]=$threeG;
                            $data_2g[$d++]=$twoG;

                        }

                        $m=count($data_m);
                        



                        echo "
                                      
                                        <script type='text/javascript'>
                                            console.log('1');
                                            Highcharts.chart('dev_distibution_div',{
                                                chart:{
                                                    type:'column'
                                                },
                                                title:{
                                                    text:'Technology Usage Distribution (User Count)'
                                                },
                                                xAxis:{
                                                    categories:["; 
                                                    for($i=0;$i<$m;$i++){

                                                        $val=$data_m[$i];
                                                    echo "'{$val}',";
                                    
                                                    }

                                                    
                                                    echo "]
                                                },
                                                yAxis:{
                                                    min:0,
                                                    title:{
                                                        text:'User Count'
                                                    },
                                                    stackLabels:{
                                                        enabled:true,
                                                        style:{
                                                            fontWeight:'bold',
                                                            color:(Highcharts.theme && Highcharts.theme.textcolor) || 'gray'
                                                        }
                                                    }
                                                },
                                                legend:{
                                                    align:'right',
                                                    x:-30,
                                                    verticalAlign:'top',
                                                    y:18,
                                                    floating:true,
                                                    backgroundColor:(Highcharts.theme && Highcharts.theme.textcolor) || 'gray',
                                                    borderColor:'#CCC',
                                                    borderWidth:1,
                                                    shadow:false
                                                },
                                                tooltip:{
                                                    headerFormat:'<b>{point.x}</b><br/>',
                                                    pointFormat:'{series.name}:{point.y}<br/>Total:{point.stackTotal}'
                                                },
                                                plotOptions:{
                                                    column:{
                                                        stacking:'normal',
                                                        dataLabels:{
                                                            enabled:true,
                                                            color:(Highcharts.theme && Highcharts.theme.textcolor) || 'white'
                                                        }
                                                    }
                                                },
                                                series:[{
                                                    name:'4G',
                                                    data:["; 
                                                    for($i=0;$i<$m;$i++){

                                                        $val=$data_4g[$i];
                                                    echo "{$val},";
                                    
                                                    }

                                                    
                                                    echo "]
                                                },{
                                                    name:'3G',
                                                    data:["; 
                                                    for($i=0;$i<$m;$i++){

                                                        $val=$data_3g[$i];
                                                    echo "{$val},";
                                    
                                                    }

                                                    
                                                    echo "]
                                                },{
                                                    name:'2G',
                                                    data:["; 
                                                    for($i=0;$i<$m;$i++){

                                                        $val=$data_2g[$i];
                                                    echo "{$val},";
                                    
                                                    }

                                                    
                                                    echo "]
                                                }]


                                            });
                                        </script>
                                
                                ";
                                
                            
                            
                                        

                    }
                }
            }
            
            
        ?>

 