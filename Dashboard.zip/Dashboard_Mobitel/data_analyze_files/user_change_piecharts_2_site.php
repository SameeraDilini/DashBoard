

        <?php
            
            $site=$_GET["s"];
            require_once "../db_php_files/connection.php";

            $last_1=date('Y-m',strtotime('-1 month'));

            $sql="SELECT date,SUM(total_4g_user_count),SUM(total_3g_user_count),SUM(total_2g_user_count) FROM site_summary WHERE LEFT(site_id,2)=? GROUP BY YEAR(date)+'-'+MONTH(date)";
            
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"s",$param_site);

                $param_site=$site;

                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    
                    $data=array();
                    if(mysqli_stmt_num_rows($stmt)>=1){
                        mysqli_stmt_bind_result($stmt,$date,$fourG,$threeG,$twoG);
                        
                        while(mysqli_stmt_fetch($stmt)){
                            
                            $data[0]=$date;
                            $data[1]=$fourG;
                            $data[2]=$threeG;
                            $data[3]=$twoG;

                            
                            $time=strtotime($date);
                            $d=date('Y-m',$time);
                            
                            if($d==$last_1){
                                echo "
                                      
                                        <script type='text/javascript'>
                                            
                                            google.charts.load('current',{'packages':['corechart']});
                                                google.charts.setOnLoadCallback(drawChart);

                                                function drawChart(){
                                                    var data=google.visualization.arrayToDataTable([['type','sum'],
                                                    ['4G Usage',{$fourG}],['3G Usage',{$threeG}],['2G Usage',{$twoG}]]);

                                                    var options={width:360,height:320,is3D:true,};

                                                    var chart=new google.visualization.PieChart(document.getElementById('pie_span2'));

                                                    chart.draw(data,options)
                                                }
                                                


                                        </script>
                                
                                ";
                            }else{
                                echo "<script>
                                        
                                        document.getElementById('pie_span1').text('');
                                        </script>";
                            }
                            
                        }

                    }
                }
            }
            
            
        ?>

