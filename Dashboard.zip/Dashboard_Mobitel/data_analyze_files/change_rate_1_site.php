

        <?php
            $site=$_GET["s"];
            // $site="ZH";
            require_once "../db_php_files/connection.php";

            $last_1=date('Y-m',strtotime('-1 month'));
            $last_2=date('Y-m',strtotime('-2 month'));
            $last_month_val=0;
            $last_before_month_val=0;

            $sql="SELECT date,SUM(total_user_count) FROM site_summary WHERE LEFT(site_id,2)=? GROUP BY YEAR(date)+'-'+MONTH(date)";
            
            if($stmt=mysqli_prepare($link,$sql)){
                mysqli_stmt_bind_param($stmt,"s",$param_site);

                $param_site=$site;

                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    

                    if(mysqli_stmt_num_rows($stmt)>=1){
                        mysqli_stmt_bind_result($stmt,$date,$count);
                        
                        $val=array();
                        $i=0;
                        while(mysqli_stmt_fetch($stmt)){
                            
                            $time=strtotime($date);
                            $d=date('Y-m',$time);

                            
                            if($d==$last_1){
                                
                                $last_month_val=(int)$count;
                            }
                            

                            if($d==$last_2){
                                
                                $last_before_month_val=(int)$count;
                            }
                            
   
                        }

                        // echo $last_month_val;
                        // echo $last_before_month_val;

                        if(($last_before_month_val!=0) && ($last_before_month_val!=0)){
                        
                        $diff=intval($last_month_val)-intval($last_before_month_val);

                        $final=$diff/intval($last_before_month_val);

                        echo round($final,2);
                        echo "%";

                        if($final<0){
                            echo "<script>
                            document.getElementById('user_change_rate').style.color='red';
                                    </script>";
                        }else{
                            echo "<script>
                            document.getElementById('user_change_rate').style.color='green';
                                    </script>";
                        }

                        }else{
                            echo "-";
                        }

                        // echo '<pre>';
                        // print_r($array);

                        // echo date('m');
                    }
                }
            }
            
           
        ?>

