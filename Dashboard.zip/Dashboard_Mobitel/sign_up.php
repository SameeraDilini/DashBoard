<?php
    
    //initialize a session
    session_start();

    //if the user has already logged, then redirect to the dashboard page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"]!==true){
        header("location:login.php");
        exit();
    }

    $logged=htmlspecialchars($_SESSION["state"]);

    

    if($logged=="ADMIN"){
        $logged_level="dashboard_admin.php";
        $logged_name="(admin)";
    }else if($logged=="USER"){
        $logged_level="dashboard_user.php";
        $logged_name="(user)";
    }


    //including connecton php file
    require_once "db_php_files/connection.php";

    //defininig varables and initalizing with empty values
    $username=$password=$state=$usergroup=$confirm_password="";
    $username_error=$password_error=$state_error=$usergroup_error=$confirm_password_error="";

    //processing form data when form id submitted
    if($_SERVER["REQUEST_METHOD"]=="POST"){

        //validate username
        if(empty(trim($_POST["username"]))){
            $username_error="Please enter a username";
        }else{

            //prepare a select statement
            $sql="SELECT id FROM user WHERE username=?";

            if($stmt=mysqli_prepare($link,$sql)){

                //bind variables to the prepared statement
                mysqli_stmt_bind_param($stmt,"s",$param_username);

                //set parameters
                $param_username=trim($_POST["username"]);

                //attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){

                    //store result
                    mysqli_stmt_store_result($stmt);

                    if(mysqli_stmt_num_rows($stmt)==1){
                        $username_error="This username is already taken";
                    }else{
                        $username=trim($_POST["username"]);
                    }
                }else{
                    echo "Oops ! something went wrong . Please Try again";
                }
            }

            //closing statement
            mysqli_stmt_close($stmt);
        }

        //validate password
        if(empty(trim($_POST["password"]))){
            $password_error="Please enter a password";
        }else if(strlen(trim($_POST["password"]))<6){
            $password_error="Password must have at least 6 characters";
        }else{
            $password=trim($_POST["password"]);
        }

        //validate the state
        if(empty(trim($_POST["state"]))){
            $state_error="Please enter a state";
        }else{
            $state=trim($_POST["state"]);
        }

        //validate the usergroup
        if(empty(trim($_POST["usergroup"]))){
            $usergroup_error="Please enter a usergroup";
        }else{
            $usergroup=trim($_POST["usergroup"]);
        }

        //validate confirm password
        if(empty(trim($_POST["confirm_password"]))){
            $confirm_password_error="Please confirm password.";
        }else{
            $confirm_password=trim($_POST["confirm_password"]);
            if(empty($password_error) && ($password!=$confirm_password)){
                $confirm_password_error="Password did not match.";

            }
        }

        //check input errors before inserting database
        if(empty($username_error) && empty($password_error) && empty($confirm_password_error)
            && empty($state_error) && empty($usergroup_error)){

                //prepare an insert statement
                $sql="INSERT INTO user (username,password,state,created_date,usergroup) VALUES (?,?,?,?,?)";

                if($stmt=mysqli_prepare($link,$sql)){

                    //bind variables to the prepared statement as parameters
                    mysqli_stmt_bind_param($stmt,"sssss",
                    $param_username,$param_password,$param_state,$param_c_date,$param_usergroup);

                    //set parameters
                    $param_username=$username;
                    $param_password=password_hash($password,PASSWORD_DEFAULT); //create a password hash
                    $param_state=strtoupper($state);
                    $param_c_date=date('Y-m-d');
                    $param_usergroup=$usergroup;

                    //attempt to execute the prepared statement
                    if(mysqli_stmt_execute($stmt)){

                        //redirect to the back page
                        header("location:login.php");
                    }else{
                        echo "Something went wrong !.Please Try again later";
                    }

                }
                //close statement
                mysqli_stmt_close($stmt);
            }
            //close connection
            mysqli_close($link);
    }


?>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/signup_stylesheet.css"/>

    
</head>
<body>
    <header id="log_head"><span id="log_head_span">You are logged in as <?php echo htmlspecialchars($_SESSION["username"]);echo $logged_name;?></span></header>
    <div id="home_header">
    <img src="img/Logo.png" id="home_logo"/>  
    <h1 style="color:whitesmoke;margin-top: 5%;margin-left: 15%;font-size: 20px;">
                SITE USAGE REPORT
     </h1>
    </div>

    <div id="header_bottom">
        <img src="img/home.svg" id="header_bottom_img">
        <span id="header_bottom_span"><a href="re_login.php">Home</a>&#8250 Create a New Account</span>
    </div>
    <div id="login_div">
        
        <div id="login_title">
            <h2>Create a New Account </h2>
        </div>


        <div class="container">
            <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
                <div class="form-group <?php echo (!empty($username_error)) ? 'has-error' : '';?>">
                    <label for="username" style="color:whitesmoke">Username</label>
                    <input type="text" class="form-control" placeholder="Enter Username" name="username" value="<?php echo $username;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $username_error;?></span>
                </div>
                <div class="form-group <?php echo (!empty($password_error)) ? 'has-error' : '';?>">
                    <label for="password" style="color:whitesmoke">Password</label>
                    <input type="password" class="form-control" placeholder="Enter Password" name="password" value="<?php echo $password;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $password_error;?></span>

                </div>
                <div class="form-group <?php echo (!empty($confirm_password_error)) ? 'has-error' : '';?>">
                    <label for="confirm_passwod" style="color:whitesmoke">Confirm Password</label>
                    <input type="password" class="form-control" placeholder="Re Enter Password" name="confirm_password" value="<?php echo $confirm_password;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $confirm_password_error;?></span>

                </div>
                <div class="form-group <?php echo (!empty($state_error)) ? 'has-error' : '';?>">
                    <label for="state" style="color:whitesmoke">State</label>
                    <input type="text" class="form-control" placeholder="Enter State" name="state" value="<?php echo $state;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $state_error;?></span>
                </div>
                <div class="form-group <?php echo (!empty($usergroup_error)) ? 'has-error' : '';?>">
                    <label for="usergroup" style="color:whitesmoke">User Group</label>
                    <input type="text" class="form-control" placeholder="Enter User Group" name="usergroup" value="<?php echo $usergroup;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $usergroup_error;?></span>
                </div>      

                <div class="form-group">
                <input type="submit" class="btn btn-outline-success" value="CREATE">
                <input type="reset" class="btn btn-outline-danger" value="RESET" style="margin-left: 5%;">
                <button class="btn btn-outline-warning" style="margin-left: 5%;"><a href=<?php echo $logged_level?>>Cancel</a></button>
                </div>
                
                <div class="form-group">
                
                </div>

            </form>
        </div>  
    
    </div>

</body>

</html>