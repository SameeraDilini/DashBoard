<?php
    
    //initialize a session
    session_start();

    //if the user has already logged, then redirect to the dashboard page
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]==true){
            if($_SESSION["state"]=="USER"){
                header("location:dashboard_user.php");
                exit();
            }else if($_SESSION["state"]=="ADMIN"){
                header("location:dashboard_admin.php");
                exit();
            }
        
    }

    // session_destroy();
    //including connecton php file
    require_once "db_php_files/connection.php";

    //defininig varables and initalizing with empty values
    $username=$password="";
    $username_error=$password_error="";

    //processing form data when data is submitted
    if($_SERVER["REQUEST_METHOD"]=="POST"){

        
        //checking whether the username is empty or not
        if(empty(trim($_POST["username"]))){
            $username_error="Please enter username...";

        }else{
            $username=trim($_POST["username"]);
        }

        //checking whether the password is empty or not
        if(empty(trim($_POST["password"]))){
            $password_error="Please enter password...";

        }else{
            $password=trim($_POST["password"]);
        }

        //validate credentials
        if(empty($username_error) && empty($password_error)){

            //query statement
            $sql="SELECT id,username,password,state,usergroup FROM user WHERE username=?";
            
            
            if($stmt=mysqli_prepare($link,$sql)){
                //binding variables to the prepared statement as paramters
                mysqli_stmt_bind_param($stmt,"s",$param_username);

                
                //set parameters
                $param_username=$username;
                

                //attempt to execute the prepared statement

                if(mysqli_stmt_execute($stmt)){

                    //store result
                    mysqli_stmt_store_result($stmt);
                    

                    //check if username exists , if yes then verify the password
                    if(mysqli_stmt_num_rows($stmt)==1){

                        //bind result variables
                        mysqli_stmt_bind_result($stmt,$id,$username,$hash_password,$state,$usergroup);
                        
                        if(mysqli_stmt_fetch($stmt)){
                            
                            if(password_verify($password,$hash_password)){
                                // if($password==$hash_password){
 
                                //password is correct, so stating a new session
                                // $status=session_status();
                                // if($status==PHP_SESSION_NONE){
                                    //There is no active session
                                    // session_start();
                                // }else if($status==PHP_SESSION_ACTIVE){

                                    //destroy current session and start new session
                                    // session_destroy();
                                    // session_start();
                                    
                                // }

                                $insert_sql="INSERT INTO login (username,last_accessed_date) VALUES (?,?)";   

                                if($stmt2=mysqli_prepare($link,$insert_sql)){
                                    mysqli_stmt_bind_param($stmt2,"ss",$param_username2,$param_date);
                                    //set parameters
                                    $param_username2=$username;
                                    $param_date=date('Y-m-d');

                                    if(mysqli_stmt_execute($stmt2)){
                                        // echo "okay";
                                        // echo $param_date;
                                    }else{
                                        // echo mysqli_error($link);
                                    }
                                }
                                
                                // @session_start();
                                // session_abort(true);
                                // session_destroy();

                                
                                session_regenerate_id(true);
                                
                                

                                //store data in session

                                $_SESSION["loggedin"]=true;
                                $_SESSION["id"]=$id;
                                $_SESSION["username"]=$username;
                                $_SESSION["state"]=$state;
                                $_SESSION["usergroup"]=$usergroup;

                                //redirect user to dashboard page
                                if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]==true){
                                    if($_SESSION["state"]=="USER"){
                                        header("location:dashboard_user.php");
                                        exit();
                                    }else if($_SESSION["state"]=="ADMIN"){
                                        header("location:dashboard_admin.php");
                                        exit();
                                    }
                                
                            }
                                
                                
                            }else{
                                //display an error message if password is not valid
                                $password_error="The password you entered was not valid...";
                            }
                        }
                    }else{
                        //display an error message if username does not exist
                        $username_error="No account found with that username...";
                    }
                }else{
                    echo "Oops ! Something went wrong . Please try again later .";
                }
            }

            
        }

        //close statement
        mysqli_close($link);

    }


?>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/login_stylesheet.css"/>

    
</head>
<body>
    <header id="log_head"><span id="log_head_span">You are not logged...</span></header>
    <div id="home_header">
    <img src="img/Logo.png" id="home_logo"/>  
    <h1 style="color:whitesmoke;margin-top: 5%;margin-left: 15%;font-size: 20px;">
                SITE USAGE REPORT
     </h1>
    </div>

    <div id="header_bottom">
        <img src="img/home.svg" id="header_bottom_img">
        <span id="header_bottom_span"><a href="home.php">Home</a>&#8250 Login</span>
    </div>
    <div id="login_div">
        
        <div id="login_title">
            <h2>LOGIN </h2>
        </div>


        <div class="container">
            <form class="" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
                <div class="form-group <?php echo (!empty($username_error)) ? 'has-error' : '';?>">
                    <label for="username" style="color:whitesmoke">Username</label>
                    <input type="text" class="form-control" placeholder="Enter Username" name="username" value="<?php echo $username;?>">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $username_error;?></span>
                </div>
                <div class="form-group <?php echo (!empty($password_error)) ? 'has-error' : '';?>">
                    <label for="passwod" style="color:whitesmoke">Password</label>
                    <input type="password" class="form-control" placeholder="Enter Password" name="password">
                    <span class="help-block" style="color:whitesmoke;"><?php echo $password_error;?></span>

                </div>      

                <div class="form-group">
                <input type="submit" class="btn btn-outline-danger" value="LOG">
                </div>
                
                <div class="form-group">
                
                </div>

                <div class="form-group">
                <!-- <a style="color:whitesmoke"> Forgot username or password ? </a> -->
                </div> 
                
            
            </form>
        </div>  
    
    </div>

</body>

</html>