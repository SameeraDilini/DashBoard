<?php

    $connection=mysqli_connect('localhost','root','','data_transparency');

    if(mysqli_connect_error()){

        die('Database Connection Error ! '.mysqli_connect_error());
    } else{

    // echo "Conncetion Successfull";

    }

?>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/home_stylesheet.css"/>

    
</head>
<body>
    <header id="log_head"><span id="log_head_span">You are not logged...(
        <a href="login.php" style="color:#f19e9e">Log In </a>)</span></header>
    <div id="home_header">
    <img src="img/Logo.png" id="home_logo"/>  
    </div>
    <div id="header_bottom">
        <img src="img/home.svg" id="header_bottom_img">
        <span id="header_bottom_span">Home</span>
    </div>

    <div id="home_title_div">

        <div class="container">
            <h1 style="color:whitesmoke;margin-top: 5%;margin-left: 3%;font-size: 70px;">
                SITE USAGE REPORT
            </h1>

            
        </div>

    </div>

    
             
    

</body>

</html>

<?php
    mysqli_close($connection);
?>