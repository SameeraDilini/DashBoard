
<?php

//initialize a session
session_start();

//check if the user is logged, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"]!==true){
    header("location:login.php");
    exit();
}

require_once "db_php_files/connection.php";

    $sql="SELECT * FROM usergroup";
    $district_data=mysqli_query($link,$sql);
?>

<html>

<head>
    <title>Dashboard</title>
    
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/dashboard_admin_site_stylesheet.css"/>

    <!-- <script src="js/bootstrap.bundle.min.js"></script> -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/Chart.min.js"></script>
    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type="text/javascript" src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript" src="https://code.highcharts.com/modules/exporting.js"></script>
    <script type="text/javascript" src="https://code.highcharts.com/modules/export-data.js"></script>

    <script>
        function show_change_rate_1(str){
            if(str==""){
                $('#user_change_rate').text("-");

                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#user_change_rate').html(this.responseText);
 
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/change_rate_1_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_change_rate_2(str){
            if(str==""){
                
                $('#user_volume_rate').text("-");
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        
                        $('#user_volume_rate').html(this.responseText); 
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/change_rate_2_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_user_change_1(str){
            if(str==""){
                
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#pie_span1').html(this.responseText);
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/user_change_piecharts_1_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_user_change_2(str){
            if(str==""){
                
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#pie_span2').html(this.responseText);
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/user_change_piecharts_2_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_user_distribution(str){
            if(str==""){
                
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#distibution_div').html(this.responseText);
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/user_distribution_stackedbarchart_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_data_distribution(str){
            if(str==""){
                
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#d_distibution_div').html(this.responseText);
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/datavolume_distribution_stackedbarchart_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        function show_device_distribution(str){
            if(str==""){
                
                
                return;
            }else{
                
                if(window.XMLHttpRequest){
                    
                    xmlhttp=new XMLHttpRequest();
                }else{
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function(){
                    // console.log(this.responseText);
                    if(this.readyState==4 && this.status==200){
                        $('#dev_distibution_div').html(this.responseText);
                        
                    }
                    
                };
                xmlhttp.open("GET","data_analyze_files/device_distribution_stackedbarchart_site.php?s="+str,true);
                xmlhttp.send();
                

            }
        }

        
    </script>
 

</head>
<body>
    <header id="log_head"><span id="log_head_span">You are logged in as <?php echo htmlspecialchars($_SESSION["username"]);?>(admin)

        </span>
        <span id="dropdown" class="dropdown">
            <a id="dropdown-toggle" class="dropdown link" href="javascript:;">
            <img src="img/angle-down.svg" class="dropdown_icon" id="dropdown_icon">
            </a>
        </span>
    
    </header>
    <div id="home_header">
    <img src="img/Logo.png" id="home_logo"/>  
    <h1 style="color:whitesmoke;margin-top: 5%;margin-left: 15%;font-size: 20px;">
                SITE USAGE REPORT
     </h1>
    </div>
    <div id="header_bottom">
        <img src="img/home.svg" id="header_bottom_img">
        <span id="header_bottom_span"><a href="re_login.php">Home</a></span>
    </div>
    <div id="header_bottom2">
        
        <span id="header_bottom2_span" style="color:whitesmoke"><a href="dashboard_admin.php" style="color:whitesmoke">Dashboard</a> &#8250 Site</span>
    </div>

    <div id="dashbord_container">
        <div class="container">
                    <div id="tab">
                        <nav class="navbar navbar-expand-md">
                            <div class="navbar-nav">
                                <div class="sub_tab" id="dis_tab"><a href="dashboard_admin.php" style="margin-left: 20px;">District</a></div>
                                <div class="sub_tab" id="site_tab"><a href="#" style="margin-left: 33px;color: white">Site</a></div>
                            </div>
                        </nav>
                    </div>
            </div>

            <div class="container" style="background:rgb(187, 185, 185);width:100%;height:97%;">
            
            <select id="district_selector" name="loads" size="1">
                <option value="Select a District">Select a Site</option>
                <?php

                    while($distric_array=mysqli_fetch_array($district_data)){

                     echo "<option value=".$distric_array['district_id'].">".$distric_array['district_id']."</option>";
                     
                    }
    
                ?>

                
            </select>

            <h1 style="position:absolute;top:120px;margin-left:5%;">User and Data Traffic DashBoard 
                <span id="text" style="color:green;"></span>
                    <script>
                        //for combo box
                            $(document).ready(function show_district(){

                                $('#district_selector').change(function(){
                                    var selectded_district=$(this).children("option:selected").val();
                                    // alert("You have selected "+selectded_district);
                                    $('#text').text(selectded_district);
                                    show_change_rate_1(selectded_district);
                                    show_change_rate_2(selectded_district);
                                    show_user_change_1(selectded_district);
                                    show_user_change_2(selectded_district);
                                    show_user_distribution(selectded_district);
                                    show_data_distribution(selectded_district);
                                    show_device_distribution(selectded_district);
                                    
                                    
                        
                                });

                            });
                    </script>
                </h1>


                <h4 style="position:absolute;top:240;margin-left:2%;color:#750b0b;">Last Two Months (
                    <?php echo ((int)date('m')-2);?> & <?php echo ((int)date('m')-1);?> )
                 KP1 Trend </h4>
               <div id="user_c_change" class="data_change">
                   <span class="change_value" id="user_change_rate">-</span>
                    <span class="change_span">User Count Change</span>
                </div>
               <div id="data_v_change" class="data_change">
                    <span class="change_value" id="user_volume_rate">-</span>
                   <span class="change_span">Data Volume Change</span>
                </div>

                <h4 style="position:absolute;top:640px;margin-left:2%;color:#750b0b;">Last Two Months (
                    <?php echo ((int)date('m')-2);?> & <?php echo ((int)date('m')-1);?> )
                 User Change </h4>

                 <div id="pie1" class="pie">
                   <div class="pie_div" id="pie_span1">-</div>
                    <span class="user_span">User Count for <?php echo ((int)date('m')-2);?> month</span>
                </div>
               <div id="pie2" class="pie">
                    <div class="pie_div" id="pie_span2">-</div>
                   <span class="user_span">User Count for <?php echo ((int)date('m')-1);?> month</span>
                </div>

                <h4 style="position:absolute;top:1220px;margin-left:2%;color:#750b0b;">Technology User Distribution</h4>

                 <div id="user_distribution" class="user_distribution">
                   <div class="distibution_div" id="distibution_div">-</div>
                    
                </div>

                <h4 style="position:absolute;top:1800px;margin-left:2%;color:#750b0b;">Technology Data Volume Distribution</h4>

                 <div id="data_distribution" class="data_distribution">
                   <div class="d_distibution_div" id="d_distibution_div">-</div>
                    
                </div>

                <h4 style="position:absolute;top:2380px;margin-left:2%;color:#750b0b;">Device Distribution</h4>

                 <div id="device_distribution" class="device_distribution">
                   <div class="dev_distibution_div" id="dev_distibution_div">-</div>
                    
                </div>
               
                    
        </div>

    </div>
    
    <div class="dropdown_content">
    <div id="dropdown_user_logo"><img src="img/user.png" id="user_icon"><div>
        <ul class="dropdown_ul">
            <li class="dropdown_item" style="">
                <img src="img/key.svg" class="ul_icons">
                <a class="ul_a" href="sign_up.php">Account Manage</a>
            </li>
            <li class="dropdown_item" style="">
                <img src="img/lock.svg" class="ul_icons">
                <a class="ul_a" href="db_php_files/logout.php">Logout</a>
            </li>
            
        </ul>
    </div>
             
    

</body>

<script src="js/jquery-3.3.1.min.js"></script>

<script>

     // for dropdown               
     $('#dropdown_icon').click(function(){

var clicks=$(this).data('clicks');
if(clicks){
    //odd click
    $('.dropdown_content').animate({
    opacity:'0'  
},300);


  

}else{
    //even click
    $('.dropdown_content').animate({
    opacity:'1'  
},300);

}

$(this).data('clicks',!clicks);


});


 
</script>

</html>