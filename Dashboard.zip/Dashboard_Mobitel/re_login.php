<?php

    //initialize a session
    session_start();

    //check if the user is logged, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"]!==true){
        header("location:login.php");
        exit();
    }
?>
<?php 
    $logged=htmlspecialchars($_SESSION["state"]);

    if($logged=="ADMIN"){
        $logged_level="dashboard_admin.php";
        $logged_name="(admin)";
    }else if($logged=="USER"){
        $logged_level="dashboard_user.php";
        $logged_name="(user)";
    }
    
?>
<html>

<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/re_login_stylesheet.css"/>

    
</head>
<body>
    <header id="log_head"><span id="log_head_span">You are logged in as <?php echo htmlspecialchars($_SESSION["username"]);echo $logged_name;?></span></header>
    <div id="home_header">
    <img src="img/Logo.png" id="home_logo"/>  
    <h1 style="color:whitesmoke;margin-top: 5%;margin-left: 15%;font-size: 20px;">
                SITE USAGE REPORT
     </h1>
    </div>
    <div id="header_bottom">
        <img src="img/home.svg" id="header_bottom_img">
        <span id="header_bottom_span"><a href="home.php">Home</a></span>
    </div>
    <div id="header_bottom2">
        
        <span id="header_bottom2_span"><a href="<?php echo $logged_level?>" style="color:whitesmoke">Dashboard</a> &#8250 Login</span>
    </div>

    <div id="relogin_div">

    <div class="container">
        <p style="color:whitesmoke;margin-top: 5%;margin-left: 3%;">
            You are already logged in as <?php echo htmlspecialchars($_SESSION["username"]);echo $logged_name;?> , you need to log out before logging in as different user.
        </p>

        <button class="btn btn-outline-warning" style="margin-left: 35%;"><a href="db_php_files/logout.php">Log Out</a></button>
        <button class="btn btn-outline-warning" style="margin-left: 5%;"><a href="login.php">Cancel</a></button>
    </div>

    </div>
    
             
    

</body>

</html>